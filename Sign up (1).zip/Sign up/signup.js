const form = document.getElementById("form");
const username = document.getElementById("username");
const email = document.getElementById("email");
const password = document.getElementById("password");
const password2 = document.getElementById("password2");

function checkPasswords(){
    const passwordValue = password.value.trim();
  const password2Value = password2.value.trim();
    if (passwordValue !== password2Value) {
        alert('Passwords do not match')
    } else {
        return true;
    }
}



/*
const form = document.getElementById("form");
const username = document.getElementById("username");
const email = document.getElementById("email");
const password = document.getElementById("password");
const password2 = document.getElementById("password2");

form.addEventListener("submit", (e) => {
  e.preventDefault();

  checkInputs();
});

function checkInputs() {
  const usernameValue = username.value.trim();
  const emailValue = email.value.trim();
  const passwordValue = password.value.trim();
  const password2Value = password2.value.trim();

  if (usernameValue === "") {
    setError();
  } else {
    setSuccess(username);
  }

  if (emailValue === "") {
    setError(email);
  } else if (!isEmail(email)) {
    setError(email, "Email is not valid");
  } else {
    setSuccess(email);
  }

  if (passwordValue === "") {
    setError(password);
  } else if (!validPassword()) {
      setError(password);
  } else {
    setSuccess(password);
  }
}

if (password2Value === "") {
    setError(password2);
  } else if (password2Value !== passwordValue) {
      setError(password2, 'password do not');
  } else {
    setSuccess(password2);
  }




/******Functions***************************/

function setError() {
  const formControl = input.parentElement; // .formControl
  formControl.className = "formControl error";
}

function setSuccess() {
  const formControl = input.parentElement;
  formControl.className = "formControl success";
}

function isEmail(email) {
  if (
    /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/.test(
      myForm.emailAddr.value
    )
  ) {
    return true;
  }
  return false;
}

function validPassword(password) {
  var password = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{7,15}$/;
  if (password.value.match(password)) {
    alert(
      "Your password should be at least 7 charecters long with a number, Upper & lower case letter and a special charecter"
    );
    return true;
  } else {
    return false;
  }
}
